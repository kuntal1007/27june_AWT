$(document).ready(function(){
    $("#id1").click(function(){
        alert("Hello");
        $("#d1").hide(5000);
    })
})
$(document).ready(function(){
    $("#id2").click(function(){
        alert("Hello");
        $("#d1").show(5000);
    })
})
$(document).ready(function(){
    $("#id3").click(function(){
        alert("Hello");
        $("#d1").width(200);
        $("#d1").height(200);
    })
})
$(document).ready(function(){
    $("#id4").click(function(){
        alert("Hello");
        $("#d1").width(50);
        $("#d1").height(50);
    })
})
$(document).ready(function(){
$("#id3").click(function(){
    alert("Hello");
    var MDH=parseInt($("#d1").css("height"));
    if(MDH<=150)
    {
        MDH+=10;
        $("#d1").css("height",MDH);
        $("#d1").css("width",MDH);
    }
    else{
        alert("More than 150px is not possible.");
    }
})
});
$(document).ready(function(){
    $("#id4").click(function(){
        alert("Hello");
        var MDH=parseInt($("#d1").css("height"));
        if(MDH>=20)
        {
            MDH-=10;
            $("#d1").css("height",MDH);
            $("#d1").css("width",MDH);
        }
        else{
            alert("less than 20px is not possible.");
        }
    })
    });
    
$("#id2").attr("disabled",true);
$("#id1").click(function(){
    if(confirm("Are you sure..??"))
    {
        $("#d1").hide(3000);
        $(this).attr("disabled",true);
        $("#id2").attr("disabled",false);
    }
})
$("#id2").click(function(){
    if(confirm("Are you sure..??"))
    {
        $("#d1").show(3000);
        $(this).attr("disabled",true);
        $("#id2").attr("disabled",false);
    }
})