function externalalertjs(){
    alert("Hello guys");
}
function externalconfirmjs(){
    confirm('Hello guys');
}
function externalpromptjs(){
    prompt('Hello guys');
}
console.log("Hello");

function color(){
document.body.style.backgroundColor = 'red';
}
function id1(){
document.getElementById('d1').style.backgroundColor='pink';
}
function id2(){
    document.getElementById('d2').style.backgroundColor='pink';
}
function id3(){
    document.getElementById('d3').style.backgroundColor='pink';
}
function onchng(){
    document.getElementById('id11').style.backgroundColor="blue";
    
  }
  
  function chang(){
      document.body.style.backgroundColor=document.getElementById('id01').value;
  }
  function bgchnge(){
      document.getElementById('ido').style.backgroundColor=document.getElementById('id12').value;
  }
  
  function ID1(){
      var vname=prompt("enter your Full Name");
      document.getElementById('id111').innerHTML=vname;
  }
  function ID1(){
    var vname=prompt("enter your  Name");
    document.getElementById('k1').innerHTML=vname;
    var vname=prompt("enter your  Name");
    document.getElementById('k2').innerHTML=vname;
  }