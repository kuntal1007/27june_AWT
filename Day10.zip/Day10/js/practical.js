function size(){
    document.getElementById('btn1').style.fontSize="100px";
}
function family(){
    document.getElementById('btn2').style.fontFamily="impact,charcoal,sans-serif";
}
function hide(){
    document.getElementById('btn3').style.display="none";
}
